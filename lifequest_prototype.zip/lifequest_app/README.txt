LIFEQUEST MVP

Open index.html in a modern browser. No installation or account required.

Includes: dashboard, XP and levels, random/surprise/custom quests, quest completion, explore prompts, achievements, inventory tokens, and a demo party page. Progress is saved locally in the browser.

This is a front-end prototype. Real accounts, cloud sync, live friend invites/leaderboards, geolocation and push notifications are not connected yet.
